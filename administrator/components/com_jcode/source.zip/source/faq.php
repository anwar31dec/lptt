<ul class="tab-bar grey-tab">
	<li class="active">
		<a href="#basic" data-toggle="tab"> <span class="block text-center"> <i class="fa fa-tag fa-2x"></i> </span> Basic </a>
	</li>
	<li>
		<a href="#account" data-toggle="tab"> <span class="block text-center"> <i class="fa fa-edit fa-2x"></i> </span> Account </a>
	</li>
	<li>
		<a href="#license" data-toggle="tab"> <span class="block text-center"> <i class="fa fa-exclamation-circle fa-2x"></i> </span> License </a>
	</li>	
</ul>

<div class="padding-md">

	<div class="tab-content">
		<div class="tab-pane fade in active" id="basic">
			<div class="panel-group" id="FaqBasic">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqBasic" href="#faqBasic1"> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit? </a></h4>
					</div>
					<div id="faqBasic1" class="panel-collapse collapse" style="height: 0px;">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi. Aenean id pellentesque mi, non placerat mi. Integer luctus accumsan tellus. Vivamus quis elit sit amet nibh lacinia suscipit eu quis purus. Vivamus tristique est non ipsum dapibus lacinia sed nec metus.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqBasic" href="#faqBasic2"> Lorem ipsum dolor sit amet, consectetur adipiscing elit? </a></h4>
					</div>
					<div id="faqBasic2" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqBasic" href="#faqBasic3"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid? </a></h4>
					</div>
					<div id="faqBasic3" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqBasic" href="#faqBasic4"> Food truck quinoa nesciunt laborum eiusmod? </a></h4>
					</div>
					<div id="faqBasic4" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqBasic" href="#faqBasic5"> Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident? </a></h4>
					</div>
					<div id="faqBasic5" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
			</div>
		</div><!-- /tab-pane -->
		<div class="tab-pane fade" id="account">
			<div class="panel-group" id="FaqAccount">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqAccount" href="#faqAccount1"> gravida varius velit? </a></h4>
					</div>
					<div id="faqAccount1" class="panel-collapse collapse" style="height: 0px;">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi. Aenean id pellentesque mi, non placerat mi. Integer luctus accumsan tellus. Vivamus quis elit sit amet nibh lacinia suscipit eu quis purus. Vivamus tristique est non ipsum dapibus lacinia sed nec metus.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqAccount" href="#faqAccount2"> Lorem ipsum dolor sit amet, consectetur adipiscing elit? </a></h4>
					</div>
					<div id="faqAccount2" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqAccount" href="#faqAccount3"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid? </a></h4>
					</div>
					<div id="faqAccount3" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqAccount" href="#faqAccount4"> Food truck quinoa nesciunt laborum eiusmod? </a></h4>
					</div>
					<div id="faqAccount4" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqAccount" href="#faqAccount5"> Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident? </a></h4>
					</div>
					<div id="faqAccount5" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
			</div>
		</div><!-- /tab-pane -->
		<div class="tab-pane fade" id="license">
			<div class="panel-group" id="FaqLicense">
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqLicense" href="#faqLicense1"> Lorem ipsum dolor sit amet, consecte gravida varius velit? </a></h4>
					</div>
					<div id="faqLicense1" class="panel-collapse collapse" style="height: 0px;">
						<div class="panel-body">
							Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi. Aenean id pellentesque mi, non placerat mi. Integer luctus accumsan tellus. Vivamus quis elit sit amet nibh lacinia suscipit eu quis purus. Vivamus tristique est non ipsum dapibus lacinia sed nec metus.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqLicense" href="#faqLicense2"> Lorem ipsum dolor sit amet, consectetur adipiscing elit? </a></h4>
					</div>
					<div id="faqLicense2" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqLicense" href="#faqLicense3"> Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid? </a></h4>
					</div>
					<div id="faqLicense3" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqLicense" href="#faqLicense4"> Food truck quinoa nesciunt laborum eiusmod? </a></h4>
					</div>
					<div id="faqLicense4" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
				<div class="panel panel-default">
					<div class="panel-heading">
						<h4 class="panel-title"><a class="accordion-toggle collapsed" data-toggle="collapse" data-parent="#FaqLicense" href="#faqLicense5"> Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident? </a></h4>
					</div>
					<div id="faqLicense5" class="panel-collapse collapse">
						<div class="panel-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.

							<div class="bg-grey padding-sm m-top-md">
								Example: Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam eros nibh, viverra a dui a, gravida varius velit. Nunc vel tempor nisi.
							</div>
						</div>
					</div>
				</div><!-- /panel -->
			</div><!-- /panel-group -->
		</div><!-- /tab-pane -->
		</div><!-- /tab-content -->
</div><!-- /.padding -->
<style>
	.panel.panel-default .panel-title a{
		font-size:14px;
	}
</style>