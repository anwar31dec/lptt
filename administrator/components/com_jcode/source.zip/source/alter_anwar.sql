alter table `malariafpmch_db`.`t_cfm_patientoverview` 
   change `PatientTypeId` `FormulationId` tinyint(3) NOT NULL;