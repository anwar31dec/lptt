﻿<select onchange="document.location.replace(this.value);" class="inputbox">
	<option selected="selected" value="index.php"><span style="background:url(media/mod_languages/images/en.gif);height:32px;width:32px;display:block;"></span>English</option>
	<option value="index.php" dir="ltr"> Français </option>
</select>