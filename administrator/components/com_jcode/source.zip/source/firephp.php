<?php 
	ob_start();
	include('FirePHPCore/fb.php');
 ?>