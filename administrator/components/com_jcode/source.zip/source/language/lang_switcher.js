var TEXT = '';

switch (vLang) {
	case 'en-GB' :
		TEXT = TEXT_EN;
		break;
	case 'fr-FR' :
		TEXT = TEXT_FR;
		break;
                
}

