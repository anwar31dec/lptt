<div class="page-title">	
	<h3 class="no-margin">Coming Soon</h3>
	<span>Welcome to WARP ...</span>
</div>
<!--
<div class="panel panel-default">

<div class="panel-body">
	<a class="btn btn-info" href="javascript:void(0);" onClick="onInfo()">Info</a>
	<a class="btn btn-success" href="javascript:void(0);" onClick="onSuccess()">Success</a>
	<a class="btn btn-warning" href="javascript:void(0);" onClick="onWarning()">Warning</a>					
	<a class="btn btn-danger" href="javascript:void(0);" onClick="onError()">Error</a>	
</div>	
</div>			
<script type="text/javascript">
	function onInfo(){
		msg="This is test Info.";
		onInfoMsg(msg); // jcode popup_message
	}
	function onSuccess(){
		msg="This is test Success.";
		onSuccessMsg(msg); // jcode popup_message
	}
	function onWarning(){
		msg="This is test Warning.";
		onWarningMsg(msg); // jcode popup_message
	}
	function onError(){
		msg="This is test Error.";
		onErrorMsg(msg); // jcode popup_message
	}	
</script>
-->